import requests
import re
 
def get_html_text(url):

#user-agent:

# Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36

#User-Agent 为cookis再下拉的内容，chorm浏览器按F12键

   headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'}
   try:

# coo后面 为自己登陆淘宝后。输入搜索后的cookies
        coo = 'miid=5550533931182706749; t=cf33063dcc40062833eeab52adc6d1a4; thw=cn; cna=H0WYEkbxT0MCAXx/xQ9Drd7U; hng=CN%7Czh-CN%7CCNY%7C156; tracknick=%5Cu6DD8%5Cu6DD8%5Cu6DD8%5Cu3002%5Cu3002%5Cu5C81%5Cu6708; lgc=%5Cu6DD8%5Cu6DD8%5Cu6DD8%5Cu3002%5Cu3002%5Cu5C81%5Cu6708; tg=0; enc=FFfnOr%2Bs14i7a%2F4a%2Fi4pQzsLMWd5hM%2FYrJH7SfLXDBq0a3QDXOq4qdvQ%2FR7n%2FFG6nuH65Iuvle6NXvW6uJ9VNw%3D%3D; x=e%3D1%26p%3D*%26s%3D0%26c%3D0%26f%3D0%26g%3D0%26t%3D0%26__ll%3D-1%26_ato%3D0; UM_distinctid=16a8d620f632aa-0311ab6cb52e7a-e323069-100200-16a8d620f6411f; _cc_=U%2BGCWk%2F7og%3D%3D; v=0; cookie2=16dcab0833213e26142c2fbffe5efd6b; _tb_token_=3318ebb31fe45; skt=c9dd78983ebc7b58; csg=4426d9c2; uc3=vt3=F8dBy3qDHkfP2HbEtFo%3D&id2=UNDUKSXW9i%2Fl%2FQ%3D%3D&nk2=r4H9KKk5VkLYbb6ndG4%3D&lg2=W5iHLLyFOGW7aA%3D%3D; existShop=MTU1ODI0NzAzMg%3D%3D; dnk=%5Cu6DD8%5Cu6DD8%5Cu6DD8%5Cu3002%5Cu3002%5Cu5C81%5Cu6708; mt=ci=30_1; alitrackid=www.taobao.com; lastalitrackid=www.taobao.com; swfstore=213611; whl=-1%260%260%261558255325982; uc1=cookie16=W5iHLLyFPlMGbLDwA%2BdvAGZqLg%3D%3D&cookie21=VT5L2FSpczFp&cookie15=W5iHLLyFOGW7aA%3D%3D&existShop=false&pas=0&cookie14=UoTZ7Hcu7Gp5Tg%3D%3D&tag=8&lng=zh_CN; JSESSIONID=3678816B502F06EAC59E42E13DB045D8; isg=BKSkGA4ypPYtydCLX5il1ZGMdaKcf38Prr3GqL7FMm8yaUYz90y0N8TLKYFUsQD_; l=bBSmW2m7vDr3IbbQBOCiNZax9_Q9sIRVguWbH03Wi_5BZ_81bj_OlnTrFEJ6Vj5Rsytp4R15R8e9-etki'
        
        cookies = {}
        for line in coo.split(';'):  # 浏览器伪装
            name, value = line.strip().split('=', 1)
            cookies[name] = value
        r = requests.get(url, cookies=cookies, headers=headers, timeout=30)
        r.raise_for_status()
        r.encoding = r.apparent_encoding
        return r.text
   except:
        return ''      #print("获取失败")


# 步骤2：对于每个页面，提取商品名称和价格信息
def parse_page(ilt, html):
    try:
        plt = re.findall(r'\"view_price\"\:\"[\d\.]*\"', html)  # findall搜索全部字符串，viex_price是源代码中表价格的值，后面的字符串为数字和点组成的字符串
        tlt = re.findall(r'\"raw_title\"\:\".*?\"', html)  # 找到该字符串和后面符合正则表达式的字符串
        img = re.findall(r'\"pic_url\"\:\".*?\"', html)
        for i in range(len(plt)):
            price = eval(plt[i].split(':')[1])  # re.split() 将一个字符串按照正则表达式匹配结果进行分割，返回列表类型
            title = eval(tlt[i].split(':')[1])  # 将re获得的字符串以：为界限分为两个字符串,并取第二个字符串
            image = eval(img[i].split(':')[1]) 
            ilt.append([price, title, image])
    except:
        print('')

'''
# 步骤3：将信息输出到屏幕上
def print_goods_list(ilt):
    tplt = "{:4}\t{:8}\t{:16}"  # 长度为多少
    print(tplt.format('序号', '价格', '名称'))
    count = 0
    for g in ilt:
        count = count + 1
        print(tplt.format(count, g[0], g[1]))
'''
def write_data(list, num):
    # with open('F:/taob2.txt', 'a') as data:
    #    print(list, file=data)
    for i in range(num):  # num控制把爬取到的商品写进多少到文本中
        u = list[i]
        with open('F:/taobao.txt', 'a') as data:
            print(u, file=data)


def main():
    goods = '鞋子'#要查的内容！！！！！！！！！！！！与你有关！！！！！
    depth = 5 # 要爬取几页
    start_url = 'https://s.taobao.com/search?q=' + goods
    info_list = []
    for i in range(depth):
        try:
            url = start_url + '&s=' + str(44*i)  # 44是淘宝每个页面呈现的宝贝数量
            html = get_html_text(url)
            parse_page(info_list, html)
        except:
            continue
#    print_goods_list(info_list)
    write_data(info_list, len(info_list))

main()
